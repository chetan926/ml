import hashlib
import json
import os
import zipfile
from pathlib import Path

PROJECT_ROOT = Path("D:/ml rearcch project ad")
PHASE_4_1_DIR = PROJECT_ROOT / "research_upgrade" / "phase_4_1_corrections"
AUDITS_DIR = PROJECT_ROOT / "research_upgrade" / "audits"
AUDITS_DIR.mkdir(parents=True, exist_ok=True)


def compute_sha256(filepath):
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


# 1. Generate SHA256 manifest for Phase 4.1 files
manifest = {}
for p in sorted(PHASE_4_1_DIR.rglob("*")):
    if p.is_file() and not p.name.endswith(".zip") and "__pycache__" not in p.parts:
        rel = p.relative_to(PROJECT_ROOT).as_posix()
        manifest[rel] = {
            "size_bytes": p.stat().st_size,
            "sha256": compute_sha256(p),
        }

# Also include the test file
test_file = PROJECT_ROOT / "tests" / "test_phase_4_1_corrections.py"
if test_file.exists():
    manifest["tests/test_phase_4_1_corrections.py"] = {
        "size_bytes": test_file.stat().st_size,
        "sha256": compute_sha256(test_file),
    }

manifest_path = PHASE_4_1_DIR / "PHASE_4_1_SHA256_MANIFEST.json"
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

print(f"Generated Phase 4.1 manifest with {len(manifest)} entries: {manifest_path}")

# Re-hash manifest to add itself
manifest["research_upgrade/phase_4_1_corrections/PHASE_4_1_SHA256_MANIFEST.json"] = {
    "size_bytes": manifest_path.stat().st_size,
    "sha256": compute_sha256(manifest_path),
}
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

# 2. Build ZIP archive
zip_path = AUDITS_DIR / "phase_4_1_independent_verification.zip"
print(f"Creating ZIP archive: {zip_path}...")

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for rel_path in manifest.keys():
        src_path = PROJECT_ROOT / rel_path
        if src_path.exists():
            zf.write(src_path, arcname=rel_path)

# Verify ZIP
with zipfile.ZipFile(zip_path, "r") as zf:
    corrupted = zf.testzip()
    assert corrupted is None, f"ZIP archive corrupted at: {corrupted}"
    infolist = zf.infolist()
    print(f"ZIP archive verified successfully: {len(infolist)} files included, uncompressed {sum(i.file_size for i in infolist) / 1024:.1f} KB, compressed {sum(i.compress_size for i in infolist) / 1024:.1f} KB.")

zip_sha256 = compute_sha256(zip_path)
zip_size = zip_path.stat().st_size
print(f"Archive SHA-256: {zip_sha256}")
print(f"Archive Size: {zip_size:,} bytes")

# Write ZIP manifest companion
zip_manifest = {
    "archive_name": zip_path.name,
    "size_bytes": zip_size,
    "sha256": zip_sha256,
    "total_files": len(infolist),
    "files": {i.filename: {"size": i.file_size, "crc32": f"{i.CRC:08X}"} for i in infolist},
}
with open(AUDITS_DIR / "phase_4_1_independent_verification_manifest.json", "w", encoding="utf-8") as f:
    json.dump(zip_manifest, f, indent=2)

print("All verification packaging completed successfully.")
